use school;

insert into person(name, gender, age) values("Mishu", 'M', 18);
insert into person(name, gender, age) values("Petar", 'M', 25);
insert into person(name, gender, age) values("Mimi", 'F', 24);
insert into person(name, gender, age) values("Ani", 'F', 16);

insert into weight_data(weight, person_id) values(80, 1);
insert into weight_data(weight, person_id) values(75, 1);
insert into weight_data(weight, person_id) values(50, 2);
insert into weight_data(weight, person_id) values(74, 3);
insert into weight_data(weight, person_id) values(76, 3);
insert into weight_data(weight, person_id) values(54, 4);
