create definer = root@localhost trigger AddToTimelineInsert
    after INSERT
    on Students
    for each row
begin
    insert into H_TimelineStudents(BeginDate,
                                   EndDate,
                                   studentId,
                                   Name,
                                   Num,
                                   ClassNum,
                                   ClassLetter,
                                   Birthday,
                                   EGN,
                                   EntranceExamResult)
    values (Now(),
            null,
            NEW.Id,
            NEW.Name,
            NEW.Num,
            NEW.ClassNum,
            NEW.ClassLetter,
            NEW.Birthday,
            NEW.EGN,
            NEW.EntranceExamResult);
    end;

