create definer = root@localhost trigger AddToTimelineUpdate
    after UPDATE
    on Students
    for each row
begin

    update H_TimelineStudents
    set EndDate = Now()
    where studentId = NEW.Id and EndDate is null;


    insert into H_TimelineStudents(BeginDate,
                                   EndDate,
                                   studentId,
                                   Name,
                                   Num,
                                   ClassNum,
                                   ClassLetter,
                                   Birthday,
                                   EGN,
                                   EntranceExamResult)
    values (Now(),
            null,
            NEW.Id,
            NEW.Name,
            NEW.Num,
            NEW.ClassNum,
            NEW.ClassLetter,
            NEW.Birthday,
            NEW.EGN,
            NEW.EntranceExamResult);

end;

