create definer = root@localhost trigger Students_AI_Hist
    after INSERT
    on Students
    for each row
BEGIN
	INSERT INTO H_Students
    VALUES(NULL, NOW(), 'I', NEW.Id, NEW.Name, NEW.Num,
			NEW.ClassNum, NEW.ClassLetter, NEW.Birthday, NEW.EGN, NEW.EntranceExamResult);
END;

