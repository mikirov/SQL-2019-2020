create definer = root@localhost trigger Students_AD_Hist
    after DELETE
    on Students
    for each row
BEGIN
	INSERT INTO H_Students
    VALUES(NULL, NOW(), 'D', OLD.Id, OLD.Name, OLD.Num,
			OLD.ClassNum, OLD.ClassLetter, OLD.Birthday, OLD.EGN, OLD.EntranceExamResult);
END;

