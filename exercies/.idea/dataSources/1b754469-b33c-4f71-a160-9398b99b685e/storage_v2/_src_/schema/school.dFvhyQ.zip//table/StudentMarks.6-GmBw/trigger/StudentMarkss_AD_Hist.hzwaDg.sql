create definer = root@localhost trigger StudentMarkss_AD_Hist
    after DELETE
    on StudentMarks
    for each row
BEGIN
	INSERT INTO H_StudentMarks
    VALUES(NULL, NOW(), 'D', OLD.StudentId, OLD.SubjectId, OLD.ExamDate, OLD.Mark);
END;

