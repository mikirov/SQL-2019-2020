create definer = root@localhost trigger AddToTimelineDelete
    after DELETE
    on Students
    for each row
begin

    update H_TimelineStudents
    set EndDate = Now()
    where studentId = OLD.Id and EndDate is null;

end;

