create definer = root@localhost trigger StudentMarks_AI_Hist
    after INSERT
    on StudentMarks
    for each row
BEGIN
	INSERT INTO H_StudentMarks
    VALUES(NULL, NOW(), 'I', NEW.StudentId, NEW.SubjectId, NEW.ExamDate, NEW.Mark);
END;

