create definer = root@localhost trigger StudentMarks_AU_Hist
    after UPDATE
    on StudentMarks
    for each row
BEGIN
	INSERT INTO H_StudentMarks
    VALUES(NULL, NOW(), 'U', NEW.StudentId, NEW.SubjectId, NEW.ExamDate, NEW.Mark);
END;

